import React from 'react';
import { Link } from 'react-router-dom';
import { UserCard } from './UserCard';
export const ActivitySidebar.FC = () => {
  const activities = [{
    user'Emma Wilson',
    action'uploaded',
    resource'Chemistry Notes',
    time'5m ago'
  }, {
    user'Alex Johnson',
    action'joined',
    resource'Calculus Study Group',
    time'15m ago'
  }, {
    user'Sarah Lee',
    action'commented on',
    resource'Physics Lab Report',
    time'1h ago'
  }];
  const suggestedUsers = [{
    id
    name'Michael Brown',
    course'Computer Science',
    year'2nd Year'
  }, {
    id
    name'Jessica Taylor',
    course'Biology',
    year'3rd Year'
  }, {
    id
    name'David Wilson',
    course'Mathematics',
    year'1st Year'
  }];
  return <aside className="hidden lg-col w-72 border-l border-gray-200 bg-white p-4">
      <div className="mb-8">
        <h3 className="font-medium text-gray-900 mb-4">Recent Activity</h3>
        <div className="space-y-4">
          {activities.map((activity, index) => <div key={index} className="flex items-start">
              <div className="h-8 w-8 rounded-full bg-gradient-to-r from-purple-500 to-blue-500 flex-shrink-0"></div>
              <div className="ml-3">
                <p className="text-sm text-gray-700">
                  <span className="font-medium">{activity.user}</span>{' '}
                  {activity.action}{' '}
                  <span className="font-medium">{activity.resource}</span>
                </p>
                <p className="text-xs text-gray-500">{activity.time}</p>
              </div>
            </div>)}
        </div>
      </div>
      <div>
        <h3 className="font-medium text-gray-900 mb-4">Suggested Students</h3>
        <div className="space-y-3">
          {suggestedUsers.map(user => <UserCard key={user.id} id={user.id} name={user.name} course={user.course} year={user.year} compact />)}
        </div>
      </div>
    </aside>;
};