import React from 'react';
import { Link } from 'react-router-dom';
import { FileText} from 'lucide-react';
;
  date;
  likes;
  comments;
}
export const ResourceCard.FC<ResourceCardProps> = ({
  id,
  title,
  type,
  subject,
  uploadedBy,
  date,
  likes,
  comments
}) => {
  const getIcon = () => {
    switch (type) {
      case 'video'="h-6 w-6 text-purple-500" />;
      case 'audio'="h-6 w-6 text-green-500" />;
      default="h-6 w-6 text-blue-500" />;
    }
  };
  return <div className="bg-white rounded-lg border border-gray-200 overflow-hidden hover-md transition-shadow">
      <div className="p-4">
        <div className="flex items-center mb-3">
          {getIcon()}
          <span className="ml-2 text-xs font-medium text-gray-500 uppercase">
            {type}
          </span>
          <span className="ml-auto text-xs text-gray-500">{date}</span>
        </div>
        <h3 className="font-medium text-lg text-gray-900 mb-1">{title}</h3>
        <p className="text-sm text-gray-600 mb-3">
          <span className="font-medium">{subject}</span> • Uploaded by{' '}
          <Link to={`/profile/${uploadedBy.id}`} className="text-blue-600 hover">
            {uploadedBy.name}
          </Link>
        </p>
        <div className="flex items-center justify-between mt-4">
          <div className="flex space-x-4">
            <button className="flex items-center text-gray-600 hover-blue-600">
              <ThumbsUpIcon className="h-4 w-4 mr-1" />
              <span className="text-xs">{likes}</span>
            </button>
            <button className="flex items-center text-gray-600 hover-blue-600">
              <MessageSquareIcon className="h-4 w-4 mr-1" />
              <span className="text-xs">{comments}</span>
            </button>
          </div>
          <div className="flex space-x-2">
            <button className="p-2 rounded-full text-gray-600 hover-gray-100">
              <BookmarkIcon className="h-4 w-4" />
            </button>
            <button className="p-2 rounded-full text-gray-600 hover-gray-100">
              <DownloadIcon className="h-4 w-4" />
            </button>
          </div>
        </div>
      </div>
    </div>;
};