import React from 'react';
import { Link } from 'react-router-dom';
import { User} from 'lucide-react';

export const UserCard.FC<UserCardProps> = ({
  id,
  name,
  course,
  year,
  bio,
  compact = false
}) => {
  if (compact) {
    return <div className="flex items-center justify-between bg-white rounded-lg p-3 border border-gray-200">
        <div className="flex items-center">
          <div className="h-10 w-10 rounded-full bg-gradient-to-r from-blue-500 to-purple-500 flex items-center justify-center text-white">
            <UserIcon className="h-5 w-5" />
          </div>
          <div className="ml-3">
            <Link to={`/profile/${id}`} className="font-medium text-gray-900 hover-blue-600 transition-colors">
              {name}
            </Link>
            <p className="text-xs text-gray-500">
              {course} • {year}
            </p>
          </div>
        </div>
        <button className="text-xs font-medium text-blue-600 hover-blue-800 bg-blue-50 hover-blue-100 px-3 py-1 rounded-full transition-colors">
          Follow
        </button>
      </div>;
  }
  return <div className="flex flex-col bg-white rounded-lg overflow-hidden border border-gray-200">
      <div className="p-4">
        <div className="flex items-center">
          <div className="h-12 w-12 rounded-full bg-gradient-to-r from-blue-500 to-purple-500 flex items-center justify-center text-white">
            <UserIcon className="h-6 w-6" />
          </div>
          <div className="ml-3">
            <Link to={`/profile/${id}`} className="font-medium text-lg text-gray-900 hover-blue-600 transition-colors">
              {name}
            </Link>
            <p className="text-sm text-gray-500">
              {course} • {year}
            </p>
          </div>
        </div>
        {bio && <p className="mt-2 text-sm text-gray-600">{bio}</p>}
      </div>
      <div className="px-4 py-3 bg-gray-50 border-t border-gray-200 flex justify-between">
        <button className="text-sm font-medium text-blue-600 hover-blue-800">
          View Profile
        </button>
        <button className="text-sm font-medium text-blue-600 hover-blue-800 bg-blue-50 hover-blue-100 px-3 py-1 rounded-full transition-colors">
          Follow
        </button>
      </div>
    </div>;
};