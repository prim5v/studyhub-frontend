import React from 'react';
import { Link, useLocation } from 'react-router-dom';
import { Home} from 'lucide-react';
export const Sidebar.FC = () => {
  const location = useLocation();
  const isActive = (path) => {
    return location.pathname === path;
  };
  const navItems = [{
    icon
    label'Home',
    path'/'
  }, {
    icon
    label'My Notes',
    path'/my-notes'
  }, {
    icon
    label'Study Groups',
    path'/groups'
  }, {
    icon
    label'Messages',
    path'/messages'
  }, {
    icon
    label'Favorites',
    path'/favorites'
  }];
  return <aside className="hidden md-col w-64 border-r border-gray-200 bg-white p-4">
      <Link to="/upload" className="flex items-center justify-center gap-2 w-full bg-gradient-to-r from-blue-600 to-purple-600 text-white py-3 px-4 rounded-lg font-medium mb-6 hover-90 transition-opacity">
        <PlusIcon className="h-5 w-5" />
        <span>Upload Resource</span>
      </Link>
      <nav className="flex-1">
        <ul className="space-y-1">
          {navItems.map((item, index) => <li key={index}>
              <Link to={item.path} className={`flex items-center px-4 py-3 rounded-lg ${isActive(item.path) ? 'bg-blue-50 text-blue-600' 'text-gray-700 hover-gray-100'}`}>
                <item.icon className={`h-5 w-5 ${isActive(item.path) ? 'text-blue-600' 'text-gray-500'}`} />
                <span className="ml-3 font-medium">{item.label}</span>
              </Link>
            </li>)}
        </ul>
      </nav>
      <div className="mt-6 pt-6 border-t border-gray-200">
        <div className="px-4 py-2">
          <h3 className="text-xs font-semibold text-gray-500 uppercase tracking-wider">
            My Study Groups
          </h3>
        </div>
        <ul className="mt-2 space-y-1">
          {['Calculus 101', 'Programming Fundamentals', 'Biology Lab'].map((group, index) => <li key={index}>
                <Link to={`/group/${index + 1}`} className="flex items-center px-4 py-2 text-sm rounded-md text-gray-700 hover-gray-100">
                  <span className="w-2 h-2 rounded-full bg-green-500 mr-3"></span>
                  <span className="truncate">{group}</span>
                </Link>
              </li>)}
        </ul>
      </div>
    </aside>;
};