import React from 'react';
import { BrowserRouter} from 'react-router-dom';
import { MainLayout } from './layouts/MainLayout';
import { Home } from './pages/Home';
import { Profile } from './pages/Profile';
import { StudyGroup } from './pages/StudyGroup';
import { Upload } from './pages/Upload';
import { Messages } from './pages/Messages';
export function App() {
  return <Router>
      <Routes>
        <Route path="/" element={<MainLayout>
              <Home />
            </MainLayout>} />
        <Route path="/profile/" element={<MainLayout>
              <Profile />
            </MainLayout>} />
        <Route path="/group/" element={<MainLayout>
              <StudyGroup />
            </MainLayout>} />
        <Route path="/upload" element={<MainLayout>
              <Upload />
            </MainLayout>} />
        <Route path="/messages" element={<MainLayout>
              <Messages />
            </MainLayout>} />
      </Routes>
    </Router>;
}