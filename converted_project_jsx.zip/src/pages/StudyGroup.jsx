import React, { useState } from 'react';
import { Users} from 'lucide-react';
export const StudyGroup.FC = () => {
  const [activeTab, setActiveTab] = useState('chat');
  const [message, setMessage] = useState('');
  const group = {
    id
    name'Calculus Study Group',
    description'A group for discussing calculus problems, sharing notes, and preparing for exams together.',
    subject'Mathematics',
    memberCount
    activeNow
    createdAt'3 months ago'
  };
  const messages = [{
    id
    user'Emma Wilson',
    message"Hey everyone! I just uploaded my notes from today's lecture.",
    time'10',
    isCurrentUser
  }, {
    id
    user'Alex Johnson',
    message'Thanks Emma! Those will be really helpful for the upcoming quiz.',
    time'10',
    isCurrentUser
  }, {
    id
    user'Sarah Lee',
    message"I'm still confused about the integration by parts section. Can someone explain it?",
    time'10',
    isCurrentUser
  }, {
    id
    user'Emma Wilson',
    message"Sure Sarah! Let's go through it step by step. The formula is ∫u·dv = u·v - ∫v·du",
    time'10',
    isCurrentUser
  }, {
    id
    user'Michael Brown',
    message'I found this really helpful video explaining it',
    time'10',
    isCurrentUser
  }];
  const sharedResources = [{
    id
    name'Calculus II - Integration Techniques.pdf',
    type'pdf',
    uploadedBy'Emma Wilson',
    date'2 days ago'
  }, {
    id
    name'Calculus Quiz 2 Study Guide.docx',
    type'doc',
    uploadedBy'Alex Johnson',
    date'1 week ago'
  }, {
    id
    name'Integration by Parts Tutorial.mp4',
    type'video',
    uploadedBy'Michael Brown',
    date'3 days ago'
  }];
  const getResourceIcon = (type) => {
    switch (type) {
      case 'video'="h-5 w-5 text-purple-500" />;
      case 'image'="h-5 w-5 text-blue-500" />;
      case 'pdf'="h-5 w-5 text-red-500" />;
      default="h-5 w-5 text-blue-500" />;
    }
  };
  const handleSubmit = (e.FormEvent) => {
    e.preventDefault();
    if (message.trim()) {
      // In a real app, would send message to backend
      setMessage('');
    }
  };
  return <div className="max-w-5xl mx-auto">
      {/* Group Header */}
      <div className="bg-white rounded-lg border border-gray-200 overflow-hidden mb-6">
        <div className="p-6">
          <div className="flex items-start">
            <div className="h-16 w-16 rounded-lg bg-gradient-to-r from-green-500 to-blue-500 flex items-center justify-center text-white">
              <UsersIcon className="h-8 w-8" />
            </div>
            <div className="ml-4 flex-1">
              <div className="flex justify-between">
                <div>
                  <h1 className="text-2xl font-bold text-gray-900">
                    {group.name}
                  </h1>
                  <p className="text-gray-600">
                    {group.subject} • {group.memberCount} members •{' '}
                    {group.activeNow} active now
                  </p>
                </div>
                <button className="px-4 py-2 bg-blue-600 text-white rounded-lg hover-blue-700 transition-colors">
                  Join Group
                </button>
              </div>
              <p className="mt-2 text-gray-700">{group.description}</p>
              <p className="mt-1 text-sm text-gray-500">
                Created {group.createdAt}
              </p>
            </div>
          </div>
        </div>
      </div>
      {/* Tabs */}
      <div className="bg-white rounded-lg border border-gray-200 overflow-hidden">
        <div className="flex border-b border-gray-200">
          <button className={`px-6 py-3 text-sm font-medium ${activeTab === 'chat' ? 'border-b-2 border-blue-600 text-blue-600' 'text-gray-600 hover-gray-900'}`} onClick={() => setActiveTab('chat')}>
            Chat
          </button>
          <button className={`px-6 py-3 text-sm font-medium ${activeTab === 'resources' ? 'border-b-2 border-blue-600 text-blue-600' 'text-gray-600 hover-gray-900'}`} onClick={() => setActiveTab('resources')}>
            Shared Resources
          </button>
          <button className={`px-6 py-3 text-sm font-medium ${activeTab === 'members' ? 'border-b-2 border-blue-600 text-blue-600' 'text-gray-600 hover-gray-900'}`} onClick={() => setActiveTab('members')}>
            Members
          </button>
        </div>
        {activeTab === 'chat' && <div className="flex flex-col h-[500px]">
            <div className="flex-1 overflow-y-auto p-4 space-y-4">
              {messages.map(msg => <div key={msg.id} className={`flex ${msg.isCurrentUser ? 'justify-end' 'justify-start'}`}>
                  <div className={`max-w-[70%] rounded-lg p-3 ${msg.isCurrentUser ? 'bg-blue-600 text-white rounded-br-none' 'bg-gray-100 text-gray-800 rounded-bl-none'}`}>
                    {!msg.isCurrentUser && <p className="font-medium text-sm mb-1">{msg.user}</p>}
                    <p>{msg.message}</p>
                    <p className={`text-xs mt-1 text-right ${msg.isCurrentUser ? 'text-blue-200' 'text-gray-500'}`}>
                      {msg.time}
                    </p>
                  </div>
                </div>)}
            </div>
            <div className="border-t border-gray-200 p-4">
              <form onSubmit={handleSubmit} className="flex items-center">
                <button type="button" className="p-2 rounded-full text-gray-500 hover-gray-100 mr-2">
                  <PaperclipIcon className="h-5 w-5" />
                </button>
                <input type="text" value={message} onChange={e => setMessage(e.target.value)} placeholder="Type your message..." className="flex-1 border border-gray-300 rounded-full px-4 py-2 focus-none focus-2 focus-blue-500 focus-transparent" />
                <button type="submit" disabled={!message.trim()} className={`ml-2 p-2 rounded-full ${message.trim() ? 'bg-blue-600 text-white hover-blue-700' 'bg-gray-200 text-gray-400 cursor-not-allowed'}`}>
                  <SendIcon className="h-5 w-5" />
                </button>
              </form>
            </div>
          </div>}
        {activeTab === 'resources' && <div className="p-6">
            <div className="flex justify-between items-center mb-4">
              <h3 className="font-medium text-lg text-gray-900">
                Shared Resources
              </h3>
              <button className="flex items-center text-sm font-medium text-blue-600 hover-blue-800">
                <PaperclipIcon className="h-4 w-4 mr-1" />
                Upload Resource
              </button>
            </div>
            <div className="space-y-2">
              {sharedResources.map(resource => <div key={resource.id} className="flex items-center p-3 border border-gray-200 rounded-lg hover-gray-50">
                  {getResourceIcon(resource.type)}
                  <div className="ml-3 flex-1">
                    <p className="font-medium text-gray-900">{resource.name}</p>
                    <p className="text-xs text-gray-500">
                      Uploaded by {resource.uploadedBy} • {resource.date}
                    </p>
                  </div>
                  <button className="text-xs font-medium text-blue-600 hover-blue-800">
                    Download
                  </button>
                </div>)}
            </div>
          </div>}
        {activeTab === 'members' && <div className="p-6 text-center">
            <p className="text-gray-600">
              Group members will be displayed here.
            </p>
          </div>}
      </div>
    </div>;
};