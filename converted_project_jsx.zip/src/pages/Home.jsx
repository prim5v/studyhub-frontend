import React from 'react';
import { ResourceCard } from '../components/ResourceCard';
import { StudyGroupCard } from '../components/StudyGroupCard';
import { UserCard } from '../components/UserCard';
export const Home.FC = () => {
  const trendingResources = [{
    id
    title'Calculus II - Integration Techniques',
    type'note',
    subject'Mathematics',
    uploadedBy{
      id
      name'Emma Wilson'
    },
    date'2 days ago',
    likes
    comments
  }, {
    id
    title'Introduction to Data Structures',
    type'video',
    subject'Computer Science',
    uploadedBy{
      id
      name'Alex Johnson'
    },
    date'1 week ago',
    likes
    comments
  }, {
    id
    title'Organic Chemistry - Lecture 5',
    type'note',
    subject'Chemistry',
    uploadedBy{
      id
      name'Sarah Lee'
    },
    date'3 days ago',
    likes
    comments
  }];
  const suggestedGroups = [{
    id
    name'Calculus Study Group',
    subject'Mathematics',
    memberCount
    activeNow
  }, {
    id
    name'Programming Club',
    subject'Computer Science',
    memberCount
    activeNow
  }, {
    id
    name'Biology 101',
    subject'Biology',
    memberCount
  }];
  const suggestedStudents = [{
    id
    name'James Smith',
    course'Physics',
    year'3rd Year',
    bio'Physics major with interest in quantum mechanics.'
  }, {
    id
    name'Olivia Davis',
    course'Literature',
    year'2nd Year',
    bio'Passionate about classic literature and creative writing.'
  }];
  return <div className="max-w-5xl mx-auto">
      <section className="mb-10">
        <h2 className="text-2xl font-bold text-gray-900 mb-6">
          Trending Resources
        </h2>
        <div className="grid grid-cols-1 md-cols-2 lg-cols-3 gap-4">
          {trendingResources.map(resource => <ResourceCard key={resource.id} {...resource} />)}
        </div>
      </section>
      <section className="mb-10">
        <div className="flex justify-between items-center mb-6">
          <h2 className="text-2xl font-bold text-gray-900">
            Suggested Study Groups
          </h2>
          <a href="#" className="text-sm text-blue-600 hover-blue-800">
            View All
          </a>
        </div>
        <div className="grid grid-cols-1 md-cols-2 lg-cols-3 gap-4">
          {suggestedGroups.map(group => <StudyGroupCard key={group.id} {...group} />)}
        </div>
      </section>
      <section className="mb-10">
        <div className="flex justify-between items-center mb-6">
          <h2 className="text-2xl font-bold text-gray-900">
            Students to Follow
          </h2>
          <a href="#" className="text-sm text-blue-600 hover-blue-800">
            View All
          </a>
        </div>
        <div className="grid grid-cols-1 md-cols-2 gap-4">
          {suggestedStudents.map(student => <UserCard key={student.id} {...student} />)}
        </div>
      </section>
    </div>;
};