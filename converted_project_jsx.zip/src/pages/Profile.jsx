import React, { useState } from 'react';
import { User} from 'lucide-react';
import { ResourceCard } from '../components/ResourceCard';
export const Profile.FC = () => {
  const [activeTab, setActiveTab] = useState('uploads');
  const user = {
    id
    name'Emma Wilson',
    course'Computer Science',
    year'3rd Year',
    bio'Computer Science student with a passion for web development and machine learning. I love sharing notes and helping others with coding problems.',
    contact{
      email'emma.wilson@university.edu',
      phone'+1 (555) 123-4567',
      instagram'@emma_codes'
    },
    stats{
      followers
      following
      uploads
    }
  };
  const userResources = [{
    id
    title'Calculus II - Integration Techniques',
    type'note',
    subject'Mathematics',
    uploadedBy{
      id
      name'Emma Wilson'
    },
    date'2 days ago',
    likes
    comments
  }, {
    id
    title'Data Structures & Algorithms - Lecture 3',
    type'note',
    subject'Computer Science',
    uploadedBy{
      id
      name'Emma Wilson'
    },
    date'1 week ago',
    likes
    comments
  }, {
    id
    title'Machine Learning Fundamentals',
    type'video',
    subject'Computer Science',
    uploadedBy{
      id
      name'Emma Wilson'
    },
    date'2 weeks ago',
    likes
    comments
  }];
  return <div className="max-w-4xl mx-auto">
      {/* Profile Header */}
      <div className="bg-white rounded-lg border border-gray-200 overflow-hidden mb-6">
        <div className="h-32 bg-gradient-to-r from-blue-500 to-purple-600"></div>
        <div className="px-6 py-4 relative">
          <div className="absolute -top-12 left-6 h-24 w-24 rounded-full border-4 border-white bg-gradient-to-r from-blue-500 to-purple-500 flex items-center justify-center text-white">
            <UserIcon className="h-12 w-12" />
          </div>
          <div className="ml-28">
            <div className="flex justify-between items-start">
              <div>
                <h1 className="text-2xl font-bold text-gray-900">
                  {user.name}
                </h1>
                <p className="text-gray-600">
                  {user.course} • {user.year}
                </p>
              </div>
              <div className="flex space-x-2">
                <button className="flex items-center justify-center gap-1 px-4 py-2 bg-blue-600 text-white rounded-lg hover-blue-700 transition-colors">
                  <UsersIcon className="h-4 w-4" />
                  Follow
                </button>
                <button className="flex items-center justify-center gap-1 px-4 py-2 bg-gray-100 text-gray-700 rounded-lg hover-gray-200 transition-colors">
                  <MessageSquareIcon className="h-4 w-4" />
                  Message
                </button>
              </div>
            </div>
            <p className="mt-3 text-gray-700">{user.bio}</p>
            <div className="mt-4 flex flex-wrap gap-4">
              <div className="flex items-center text-gray-700">
                <MailIcon className="h-4 w-4 mr-2 text-gray-500" />
                <span>{user.contact.email}</span>
              </div>
              <div className="flex items-center text-gray-700">
                <PhoneIcon className="h-4 w-4 mr-2 text-gray-500" />
                <span>{user.contact.phone}</span>
              </div>
              <div className="flex items-center text-gray-700">
                <InstagramIcon className="h-4 w-4 mr-2 text-gray-500" />
                <span>{user.contact.instagram}</span>
              </div>
            </div>
            <div className="mt-6 flex border-t border-gray-200 pt-4">
              <div className="mr-8">
                <span className="font-bold text-gray-900">
                  {user.stats.uploads}
                </span>
                <span className="text-gray-600 ml-1">Uploads</span>
              </div>
              <div className="mr-8">
                <span className="font-bold text-gray-900">
                  {user.stats.followers}
                </span>
                <span className="text-gray-600 ml-1">Followers</span>
              </div>
              <div>
                <span className="font-bold text-gray-900">
                  {user.stats.following}
                </span>
                <span className="text-gray-600 ml-1">Following</span>
              </div>
            </div>
          </div>
        </div>
      </div>
      {/* Tabs */}
      <div className="bg-white rounded-lg border border-gray-200 overflow-hidden">
        <div className="flex border-b border-gray-200">
          <button className={`px-6 py-3 text-sm font-medium ${activeTab === 'uploads' ? 'border-b-2 border-blue-600 text-blue-600' 'text-gray-600 hover-gray-900'}`} onClick={() => setActiveTab('uploads')}>
            Uploads
          </button>
          <button className={`px-6 py-3 text-sm font-medium ${activeTab === 'followers' ? 'border-b-2 border-blue-600 text-blue-600' 'text-gray-600 hover-gray-900'}`} onClick={() => setActiveTab('followers')}>
            Followers & Following
          </button>
          <button className={`px-6 py-3 text-sm font-medium ${activeTab === 'about' ? 'border-b-2 border-blue-600 text-blue-600' 'text-gray-600 hover-gray-900'}`} onClick={() => setActiveTab('about')}>
            About
          </button>
        </div>
        <div className="p-6">
          {activeTab === 'uploads' && <div className="grid grid-cols-1 md-cols-2 gap-4">
              {userResources.map(resource => <ResourceCard key={resource.id} {...resource} />)}
            </div>}
          {activeTab === 'followers' && <div className="text-center py-8">
              <p className="text-gray-600">
                Followers and following information will be displayed here.
              </p>
            </div>}
          {activeTab === 'about' && <div className="text-center py-8">
              <p className="text-gray-600">
                Additional profile information will be displayed here.
              </p>
            </div>}
        </div>
      </div>
    </div>;
};