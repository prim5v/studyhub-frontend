import React, { useState } from 'react';
import { FileText} from 'lucide-react';
export const Upload.FC = () => {
  const [resourceType, setResourceType] = useState('note');
  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');
  const [subject, setSubject] = useState('');
  const [course, setCourse] = useState('');
  const handleSubmit = (e.FormEvent) => {
    e.preventDefault();
    // In a real app, would send data to backend
    console.log({
      resourceType,
      title,
      description,
      subject,
      course
    });
  };
  return <div className="max-w-3xl mx-auto">
      <div className="bg-white rounded-lg border border-gray-200 overflow-hidden">
        <div className="p-6">
          <h1 className="text-2xl font-bold text-gray-900 mb-6">
            Upload Resource
          </h1>
          <form onSubmit={handleSubmit}>
            <div className="mb-6">
              <label className="block text-gray-700 font-medium mb-3">
                Resource Type
              </label>
              <div className="grid grid-cols-1 md-cols-3 gap-3">
                <button type="button" onClick={() => setResourceType('note')} className={`flex flex-col items-center justify-center p-4 border rounded-lg ${resourceType === 'note' ? 'border-blue-500 bg-blue-50 text-blue-700' 'border-gray-200 hover-gray-300 text-gray-700'}`}>
                  <FileTextIcon className="h-8 w-8 mb-2" />
                  <span className="font-medium">Note / Document</span>
                </button>
                <button type="button" onClick={() => setResourceType('video')} className={`flex flex-col items-center justify-center p-4 border rounded-lg ${resourceType === 'video' ? 'border-blue-500 bg-blue-50 text-blue-700' 'border-gray-200 hover-gray-300 text-gray-700'}`}>
                  <VideoIcon className="h-8 w-8 mb-2" />
                  <span className="font-medium">Video Recording</span>
                </button>
                <button type="button" onClick={() => setResourceType('audio')} className={`flex flex-col items-center justify-center p-4 border rounded-lg ${resourceType === 'audio' ? 'border-blue-500 bg-blue-50 text-blue-700' 'border-gray-200 hover-gray-300 text-gray-700'}`}>
                  <MicIcon className="h-8 w-8 mb-2" />
                  <span className="font-medium">Audio Recording</span>
                </button>
              </div>
            </div>
            <div className="mb-6">
              <label htmlFor="title" className="block text-gray-700 font-medium mb-2">
                Title
              </label>
              <input type="text" id="title" value={title} onChange={e => setTitle(e.target.value)} placeholder="e.g., Calculus II - Integration Techniques" className="w-full border border-gray-300 rounded-lg px-4 py-2 focus-none focus-2 focus-blue-500 focus-transparent" required />
            </div>
            <div className="mb-6">
              <label htmlFor="description" className="block text-gray-700 font-medium mb-2">
                Description
              </label>
              <textarea id="description" value={description} onChange={e => setDescription(e.target.value)} placeholder="Provide a brief description of your resource..." className="w-full border border-gray-300 rounded-lg px-4 py-2 h-24 focus-none focus-2 focus-blue-500 focus-transparent" />
            </div>
            <div className="grid grid-cols-1 md-cols-2 gap-4 mb-6">
              <div>
                <label htmlFor="subject" className="block text-gray-700 font-medium mb-2">
                  Subject
                </label>
                <select id="subject" value={subject} onChange={e => setSubject(e.target.value)} className="w-full border border-gray-300 rounded-lg px-4 py-2 focus-none focus-2 focus-blue-500 focus-transparent" required>
                  <option value="">Select a subject</option>
                  <option value="mathematics">Mathematics</option>
                  <option value="computerScience">Computer Science</option>
                  <option value="physics">Physics</option>
                  <option value="chemistry">Chemistry</option>
                  <option value="biology">Biology</option>
                  <option value="literature">Literature</option>
                  <option value="history">History</option>
                  <option value="economics">Economics</option>
                </select>
              </div>
              <div>
                <label htmlFor="course" className="block text-gray-700 font-medium mb-2">
                  Course (Optional)
                </label>
                <input type="text" id="course" value={course} onChange={e => setCourse(e.target.value)} placeholder="e.g., CS101, MATH202" className="w-full border border-gray-300 rounded-lg px-4 py-2 focus-none focus-2 focus-blue-500 focus-transparent" />
              </div>
            </div>
            <div className="mb-6">
              <label className="block text-gray-700 font-medium mb-2">
                Upload File
              </label>
              <div className="border-2 border-dashed border-gray-300 rounded-lg p-6 text-center">
                <UploadIcon className="mx-auto h-12 w-12 text-gray-400 mb-2" />
                <p className="text-gray-700 mb-1">
                  Drag and drop your file here, or
                </p>
                <button type="button" className="text-blue-600 font-medium hover-blue-800">
                  Browse Files
                </button>
                <p className="text-xs text-gray-500 mt-2">
                  {resourceType === 'note' && 'Supports PDF, DOCX, PPT, JPG, PNG (Max 50MB)'}
                  {resourceType === 'video' && 'Supports MP4, MOV, AVI (Max 200MB)'}
                  {resourceType === 'audio' && 'Supports MP3, WAV (Max 100MB)'}
                </p>
              </div>
            </div>
            <div className="flex justify-end">
              <button type="button" className="px-4 py-2 text-gray-700 font-medium hover-gray-100 rounded-lg mr-2">
                Cancel
              </button>
              <button type="submit" className="px-4 py-2 bg-blue-600 text-white font-medium rounded-lg hover-blue-700">
                Upload Resource
              </button>
            </div>
          </form>
        </div>
      </div>
    </div>;
};